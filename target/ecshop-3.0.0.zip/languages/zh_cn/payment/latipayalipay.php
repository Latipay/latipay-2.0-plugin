<?php
/*
 * ----------------------------------------------------------------------------
 * 功能描述：latipay支付语言包
 * ----------------------------------------------------------------------------
 */

global $_LANG;


$_LANG['latipayalipay'] = 'latipay支付宝';
$_LANG['latipayalipay_desc'] = 'latipay支付宝';
$_LANG['latipayalipay_key'] = 'key';
$_LANG['latipayalipay_walletid'] = 'walletid';
$_LANG['latipayalipay_mchid'] = 'merchantCode';
$_LANG['latipayalipay_is_spotpay'] = 'is_spotpay';
$_LANG['latipayalipay_button'] = '立即用latipay支付宝支付';
$_LANG['latipayalipay_error'] = '支付超时或者密码输入错误，请返回重试！';

?>