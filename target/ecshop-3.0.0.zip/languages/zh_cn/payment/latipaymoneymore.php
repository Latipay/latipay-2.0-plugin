<?php
/*
 * ----------------------------------------------------------------------------
 * 功能描述：latipay支付语言包
 * ----------------------------------------------------------------------------
 */

global $_LANG;


$_LANG['latipaymoneymore'] = 'latipay 钱多多';
$_LANG['latipaymoneymore_desc'] = 'latipay 钱多多';
$_LANG['latipaymoneymore_key'] = 'key';
$_LANG['latipaymoneymore_walletid'] = 'walletid';
$_LANG['latipaymoneymore_mchid'] = 'merchantCode';
$_LANG['latipaymoneymore_button'] = '立即用latipay钱多多支付';

?>