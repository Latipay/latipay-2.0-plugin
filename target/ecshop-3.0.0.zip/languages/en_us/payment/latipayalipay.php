<?php
/*
 * ----------------------------------------------------------------------------
 * 功能描述：latipay支付语言包
 * ----------------------------------------------------------------------------
 */

global $_LANG;


$_LANG['latipayalipay'] = 'latipay alipay';
$_LANG['latipayalipay_desc'] = 'latipay alipay';
$_LANG['latipayalipay_key'] = 'key';
$_LANG['latipayalipay_walletid'] = 'walletid';
$_LANG['latipayalipay_mchid'] = 'merchantCode';
$_LANG['latipayalipay_is_spotpay'] = 'is_spotpay';
$_LANG['latipayalipay_button'] = 'latipay alipay';
//$_LANG['latipayalipay_error'] = '支付超时或者密码输入错误，请返回重试！';

?>