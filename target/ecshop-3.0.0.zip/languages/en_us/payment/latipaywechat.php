<?php
/*
 * ----------------------------------------------------------------------------
 * 功能描述：latipay支付语言包
 * ----------------------------------------------------------------------------
 */

global $_LANG;


$_LANG['latipaywechat'] = 'latipay wechat pay';
$_LANG['latipaywechat_desc'] = 'latipay wechat pay';
$_LANG['latipaywechat_key'] = 'key';
$_LANG['latipaywechat_walletid'] = 'walletid';
$_LANG['latipaywechat_mchid'] = 'merchantCode';
$_LANG['latipaywechat_button'] = 'latipay wechat pay';
// $_LANG['latipay_error'] = '支付超时或者密码输入错误，请返回重试！';

?>