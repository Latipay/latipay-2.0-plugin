<?php
/*
 * ----------------------------------------------------------------------------
 * 功能描述：latipay支付语言包
 * ----------------------------------------------------------------------------
 */

global $_LANG;


$_LANG['latipayonlinebank'] = 'latipay onlinebank';
$_LANG['latipayonlinebank_desc'] = 'latipay onlinebank';
$_LANG['latipayonlinebank_key'] = 'key';
$_LANG['latipayonlinebank_walletid'] = 'walletid';
$_LANG['latipayonlinebank_mchid'] = 'merchantCode';
$_LANG['latipayonlinebank_button'] = 'latipay onlinebank';
// $_LANG['latipayonlinebank_error'] = '支付超时或者密码输入错误，请返回重试！';

?>