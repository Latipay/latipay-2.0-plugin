<?php
/*
 * ----------------------------------------------------------------------------
 * 功能描述：latipay支付语言包
 * ----------------------------------------------------------------------------
 */

global $_LANG;


$_LANG['latipaymoneymore'] = 'latipay moneymore';
$_LANG['latipaymoneymore_desc'] = 'latipay moneymore';
$_LANG['latipaymoneymore_key'] = 'key';
$_LANG['latipaymoneymore_walletid'] = 'walletid';
$_LANG['latipaymoneymore_mchid'] = 'merchantCode';
$_LANG['latipaymoneymore_button'] = 'latipay moneymore';

?>