<?php
// Text
$_['text_title'] = '微信支付|支付寶|錢多多 <img src="/image/catalog/payment/latipay2.png" width="204px" height="45px" />';

$_['text_payment_method'] = '付款方式 : ';
$_['text_payment_method_alert'] = '請選擇付款方式';

$_['text_alipay'] = '支付寶';
$_['text_wechat'] = '微信';
$_['text_onlineBank'] = '銀聯支付';
$_['text_moneymore'] = '錢多多';