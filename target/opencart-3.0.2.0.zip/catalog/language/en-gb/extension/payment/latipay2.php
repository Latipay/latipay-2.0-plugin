<?php
// Text
$_['text_title'] = 'Wechat Pay|Alipay|JDPay|Online Banking <img src="/image/catalog/payment/latipay2.png" width="204px" height="45px" />';

$_['text_payment_method'] = 'Payment Method : ';

$_['text_alipay'] = 'Alipay';
$_['text_wechat'] = 'Wechat';
$_['text_onlineBank'] = 'Online Bank';