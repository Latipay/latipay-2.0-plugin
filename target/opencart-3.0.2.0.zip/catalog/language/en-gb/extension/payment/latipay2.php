<?php
// Text
$_['text_title'] = 'Wechat Pay|Alipay|MoneyMore <img src="/image/catalog/payment/latipay2.png" width="204px" height="45px" />';

$_['text_payment_method'] = 'Payment Method : ';
$_['text_payment_method_alert'] = 'Please select the payment method!';

$_['text_alipay'] = 'Alipay';
$_['text_wechat'] = 'Wechat';
$_['text_onlineBank'] = 'Online Bank';
$_['text_moneymore'] = 'MoneyMore';